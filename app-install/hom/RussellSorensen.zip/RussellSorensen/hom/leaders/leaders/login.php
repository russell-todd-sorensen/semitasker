<?php
include_once('inc/globals.config.php');

if ($_SESSION['hom']['user']) {
	header('location: index.php');	
}

if (@$_POST) {
	$entered_data = $_POST;
	$db = new mysqli(DB_HOST, DB_USER, DB_PWD, DB_NAME);
	//Check if user exists	
	$email = strtolower(mysqli_real_escape_string($db, $_POST['email']));
	$sql = "SELECT * FROM users WHERE email='".$email."'";
	$result = $db->query($sql);
	$user = $result->fetch_array(MYSQLI_ASSOC);
		
	if (@$user && $email!='') {
		//User exists, check password	
		$password = sha1($_POST['password'].$user['created']);	
		if ($user['password']==$password) {
			//Accurate user and password, do login	
			$_SESSION['hom']['user'] = $user['user_id'];
			$_SESSION['hom']['role'] = $user['role'];
			//Set expiration 30 minutes out
			$_SESSION['hom']['expire'] = time()+SESSION_EXPIRY;
			
			if ($_POST['remember']) {
				$expire = time() + 60*60*24*45;
				setcookie('remember_me', $email, $expire);	
			}
			else {
				if(isset($_COOKIE['remember_me'])) {
					$past = time() - 100;
					setcookie('remember_me', 'gone', $past);
				}
			}
			
			header('location: index.php');
		}
		else {
			//Incorrect password	
			$_SESSION['hom']['message'] = array("error", "The password entered was incorrect. Please try again");
		}
	}
	else {
		$_SESSION['hom']['message'] = array("error", "The email entered was not found. Please try again");	
	}
}

if ($_COOKIE['remember_me']) {
	$form_email = $_COOKIE['remember_me'];	
}
else if ($entered_data) {
	$form_email = $entered_data['email'];
}

$page['id'] = "Login";
$page['title'] = "Log In";
?>

<?php include('header.php'); ?>
<div id="main">
	<div id="notifications">
        
    </div>
    <div id="search-bar">
    
    </div>
    <div id="lower-area">
        <h2>Log in</h2>
        <div class="main-form">
            <form method="post" autocomplete="off">
                <input type="email" name="email" required autocomplete="off" value="<?php echo $form_email; ?>" placeholder="Email address" />
                <input type="password" name="password" required autocomplete="off" placeholder="Password" />
                <input type="checkbox" name="remember" value="1" id="remember"<?php if ($_COOKIE['remember_me']) { ?> checked<?php } ?>> <label for="remember" class="checkbox-label">Remember me?</label>
                <input type="submit" name="submit" value="Log In" />
            </form>
        </div>
    </div>
</div>
<?php include('footer.php'); ?>
