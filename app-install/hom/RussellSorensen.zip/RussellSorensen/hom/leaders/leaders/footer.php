<?php 
/* FOOTER TEMPLATE */
?>
<div id="footer-bar">
	<span id="copyright">&copy; <?php echo date("Y"); ?> House of Mercy</span>
    <?php if (isset($_SESSION['hom']) && $page['id']!='Home') { ?>	
	<div class="quick-links">
		<a href="<?php if ($page['backlink']) { echo $page['backlink']; } else { ?>index.php<?php } ?>"><span class="icon-arrow-left"></span> Back</a>
    </div>
    <?php } ?>
</div>
</body>
</html>
