<?php

date_default_timezone_set('America/Los_Angeles');

define('DB_HOST', 'db648486457.db.1and1.com');
define('DB_USER', 'dbo648486457');
define('DB_PWD', 'GfR>y@bsVb064yS');
define('DB_NAME', 'db648486457');
define('SESSION_EXPIRY', 1800);
define('BASE_URL', '//'.$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']));

include_once('utils.inc.php');

?>