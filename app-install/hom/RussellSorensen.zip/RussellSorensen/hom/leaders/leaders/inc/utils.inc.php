<?php

session_start();
if (isset($_SESSION['hom'])) {
	//If session is not expired, update expiration or end session
	if (time()<$_SESSION['hom']['expire']) {
		$_SESSION['hom']['expire'] = time()+SESSION_EXPIRY;
	}
	else {
		//Session has expired
		header('location: logout.php');
	}
}

function processForDBEntry($db, $data) {
	if (is_array($data)) {
		foreach ($data as $k=>&$v) {
			$v = mysqli_real_escape_string($db, $v);
		}
	}
	else {
		$data = mysqli_real_escape_string($db, $data);
	}	
	return $data;
}

?>