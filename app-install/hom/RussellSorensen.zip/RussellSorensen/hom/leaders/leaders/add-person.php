<?php
include_once('inc/globals.config.php');

if (!isset($_SESSION['hom'])) {
	header('location: login.php');	
}

$db = new mysqli(DB_HOST, DB_USER, DB_PWD, DB_NAME);

/*------------------------------------------------
    GENERAL PAGE PROCESSING
------------------------------------------------*/

$sql = "SELECT * FROM user_profiles LEFT JOIN users ON user_profiles.user_id=users.user_id WHERE users.user_id='".$_REQUEST['uid']."'";
$result = $db->query($sql);
$user = $result->fetch_array(MYSQLI_ASSOC);

$sql = "SELECT house_id FROM conn_user_to_house WHERE user_id='".$user['user_id']."'";
$result = $db->query($sql);
$user_house = $result->fetch_array(MYSQLI_ASSOC);

if ($user['phone']) {
	$user['phone'] = "(".substr($user['phone'], 0, 3).") ".substr($user['phone'], 3, 3)."-".substr($user['phone'],6);	
}
else {
	$user['phone'] = "";
}

//Get last edited by info
$last_edited_by = $user['last_edited_by'];

if ($last_edited_by) {
	$sql = "SELECT first_name, last_name FROM user_profiles WHERE user_id='".$last_edited_by."'";
	$result = $db->query($sql);
	$last_edited_by = $result->fetch_array(MYSQLI_ASSOC);
	$user['last_edited_by'] = $last_edited_by['first_name']." ".$last_edited_by['last_name'];
	$display_edited_data = true;
}

$page['id'] = 'Add-Person';
$page['title'] = 'Add a new participant';
$page['backlink'] = 'manage-people.php';

/*------------------------------------------------
    /END GENERAL PAGE PROCESSING
------------------------------------------------*/

/*------------------------------------------------
    ADMIN PAGE PROCESSING
------------------------------------------------*/

if ($_SESSION['hom']['role']==1) {
	//Collect all house information
	$sql = "SELECT * FROM houses ORDER BY name ASC";
	$result = $db->query($sql);
	while ($row = $result->fetch_assoc()) {
		$houses[] = $row;
	}
	
	$content['title'] = 'Add a participant';
	$content['intro'] = 'Use this form to add a new participant';
	$content['action'] = 'add';
			
	$page['template'] = "person-admin.php";
}

/*------------------------------------------------
    /END ADMIN PAGE PROCESSING
------------------------------------------------*/

/*------------------------------------------------
    GENERAL PAGE PROCESSING
------------------------------------------------*/

else {
	//This page is not for non admin users
	if ($_SESSION['hom']['role']!=1) {
		header('location: '.BASE_URL);	
	}
}

/*------------------------------------------------
    /END GENERAL PAGE PROCESSING
------------------------------------------------*/

?>

<?php include('header.php'); ?>
<div id="main">
	<div id="notifications"></div>
    <div id="search-bar">
    	<h2><!--<span class="icon-magnifying-glass"></span>Find Someone--></h2>
    </div>
    <?php include ('templates/'.$page['template']); ?>
</div>
<?php include('footer.php'); ?>