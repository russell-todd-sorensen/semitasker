<?php
include_once('inc/globals.config.php');

if (!isset($_SESSION['hom'])) {
	header('location: login.php');	
}

$db = new mysqli(DB_HOST, DB_USER, DB_PWD, DB_NAME);

$page['id'] = 'Manage-Reports';

/*------------------------------------------------
    GENERAL PAGE PROCESSING
------------------------------------------------*/

$sql = "SELECT house_id FROM conn_user_to_house WHERE user_id='".$_SESSION['hom']['user']."'";
$result = $db->query($sql);
$house = $result->fetch_array(MYSQLI_ASSOC);

$this_month = array(date("m"), date("F"), date("Y"), date("Y-m-d"));
$last_month = array(date("m", strtotime("-1 month")), date("F", strtotime("-1 month")), date("Y", strtotime("-1 month")), date("Y-m-d", strtotime("-1 month")));

$month_start = date("Y-m-01");
$month_end = date('Y-m-t');
$last_month_start = date("Y-m-01", strtotime($month_start.' -1 month'));
$last_month_end = date("Y-m-t", strtotime($last_month_start));

$sql =  "SELECT * FROM reports LEFT JOIN conn_user_to_house ON reports.user_id=conn_user_to_house.user_id WHERE house_id='".$house['house_id']."' AND date>='".$last_month_start."' AND date<='".$month_end."' ORDER BY date DESC";
$result = $db->query($sql);
while ($row = $result->fetch_assoc()) {
	$raw_reports[] = $row;
}

if (@$raw_reports) {
	foreach($raw_reports as $k=>&$v) {
		$sql =  "SELECT first_name, last_name FROM user_profiles WHERE user_id='".$v['user_id']."'";
		$result = $db->query($sql);
		$name = $result->fetch_array(MYSQLI_ASSOC);
		$v['name'] = $name['first_name']." ".$name['last_name'];	
		$v['display_date'] = date("M j, Y", strtotime($v['date']));
		//Set type name
		switch ($v['type']) {
			case 1: $v['type_name'] = "Update"; break;
			case 2: $v['type_name'] = "Violation"; break;
			case 3: $v['type_name'] = "UA Test"; break;
			case 4: $v['type_name'] = "Breathalyzer Test"; break;
		}
		
		//Process nl2br for comment
		$v['comment'] = nl2br($v['comment']);
	}
}

$reports[0] = array("title"=>date("F, Y", strtotime($this_month[3])), "entries"=>array());
$reports[1] = array("title"=>date("F, Y", strtotime($last_month[3])), "entries"=>array());
foreach ($raw_reports as $k=>$v) {
	if ($v['date']>=$month_start && $v['date']<=$month_end) {
		array_push($reports[0]['entries'], $v);	
	}
	else {
		array_push($reports[1]['entries'], $v);	
	}
}


$page['title'] = 'Manage Reports';
$page['template'] = "reports.php";	


/*------------------------------------------------
    /END GENERAL PAGE PROCESSING
------------------------------------------------*/

?>

<?php include('header.php'); ?>
<div id="main">
	<div id="notifications"></div>
    <div id="search-bar">
    	<h2><!--<span class="icon-magnifying-glass"></span>Find Someone--></h2>
    </div>
    <?php include ('templates/'.$page['template']); ?>
</div>
<?php include('footer.php'); ?>