<?php
include_once('inc/globals.config.php');

if (!isset($_SESSION['hom'])) {
	header('location: login.php');	
}

$db = new mysqli(DB_HOST, DB_USER, DB_PWD, DB_NAME);

$page['id'] = 'Manage-Houses';

/*------------------------------------------------
    ADMIN PAGE PROCESSING
------------------------------------------------*/

if ($_SESSION['hom']['role']==1) {
	$sql = "SELECT * FROM houses ORDER BY name ASC";
	$result = $db->query($sql);
	while ($row = $result->fetch_assoc()) {
		$houses[] = $row;
	}
	
	$page['title'] = 'Manage Houses';
	$page['template'] = "houses-admin.php";
}

/*------------------------------------------------
    /END ADMIN PAGE PROCESSING
------------------------------------------------*/

/*------------------------------------------------
    GENERAL PAGE PROCESSING
------------------------------------------------*/

else {
	//This page is not for non admin users
	if ($_SESSION['hom']['role']!=1) {
		header('location: index.php');	
	}
}

/*------------------------------------------------
    /END GENERAL PAGE PROCESSING
------------------------------------------------*/

?>

<?php include('header.php'); ?>
<div id="main">
	<div id="notifications"></div>
    <div id="search-bar">
    	<h2><!--<span class="icon-magnifying-glass"></span>Find Someone--></h2>
    </div>
    <?php include ('templates/'.$page['template']); ?>
</div>
<?php include('footer.php'); ?>