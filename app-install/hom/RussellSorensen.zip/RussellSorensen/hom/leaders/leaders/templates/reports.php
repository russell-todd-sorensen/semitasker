<div id="lower-area">
    <h2>Manage reports</h2>
    <p>Manage this month and last month's participant reports.</p>
    <p><a href="add-report.php" class="button"><span class="icon-report-plus"></span> Add a New Entry</a></p>	
    <?php if ($reports) { ?>
    <?php foreach ($reports as $k=>$v) { ?>
    <?php if ($v['entries']) { ?>
    <div class="main-form">
        <fieldset>
            <legend><?php echo $v['title']; ?></legend>
            <?php foreach ($v['entries'] as $x=>$y) { ?>
            <div class="report list-link<?php if ($x % 2 == 0) { ?> lighter<?php } ?>">
                <table border="0" cellpadding="0" cellspacing="0" width="100%">
                    <tr>
                        <td width="45%"><?php echo $y['name']; ?></td>
                        <td width="25%"><?php echo $y['type_name']; ?></td>
                        <td width="25%"><?php echo $y['display_date']; ?></td>
                        <td width="5%"><a href="process-report.php?rid=<?php echo $y['report_id']; ?>&action=delete" onclick="return confirm('Are you sure you want to delete this entry?')" title="Delete Entry"><span class="icon-x-circle list-link-control"></span></a></td>
                    </tr>
                </table>
                <?php if ($y['type']==3 || $y['type']==4) { ?>
                <?php } ?>
                <?php if ($y['comment']) { ?>
                <p class="comment"><?php echo $y['comment']; ?>
                <?php } ?>
            </div>
            <?php } ?>
        </fieldset>
    </div>
    <?php } ?>
    <?php } ?>			
    <?php } ?>
</div>  