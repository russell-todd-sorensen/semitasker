<div id="lower-area">
    <h2>Manage Participants</h2>
    <p>Manage the important information of all participants</p>
    <p><a href="add-person.php" class="button"><span class="icon-person-plus"></span> Add a New Participant</a></p>
    <div class="main-form">
        <label>Filter By Program Status</label>
        <form method="get">
            <select name="program_status" onChange="this.form.submit()">
                <option value="1"<?php if ($program_status==1) { ?> selected<?php } ?>>Active Participants</option>
                <option value="2"<?php if ($program_status==2) { ?> selected<?php } ?>>Terminated</option>
                <option value="3"<?php if ($program_status==3) { ?> selected<?php } ?>>Self Terminated</option>
                <option value="4"<?php if ($program_status==4) { ?> selected<?php } ?>>Left Program</option>
            </select>	            
        </form>
    </div>
    <?php if ($participants) { ?>
    <div class="report-table">
        <?php foreach($participants as $k=>$v) { ?>
        <div class="list-link<?php if ($k % 2 == 0) { ?> lighter<?php } ?>">
            <a href="process-person.php?uid=<?php echo $v['user_id']; ?>&action=delete" title="Delete <?php echo $v['first_name']." ".$v['last_name']; ?>"onclick="return confirm('Are you sure you want to delete this participant?')"><span class="icon-x-circle list-link-control"></span></a>
            <a href="edit-person.php?uid=<?php echo $v['user_id']; ?>"><span class="icon-pencil list-link-control" title="Edit <?php echo $v['first_name']." ".$v['last_name']; ?>"></span></a>
            <a href="edit-person.php?uid=<?php echo $v['user_id']; ?>"><?php echo $v['first_name']." ".$v['last_name']; ?></a>
        </div>
        
        <?php } ?>
        <p class="small post-info">There are <?php echo count($participants); ?> participants</p>
    </div>
    <?php } ?>
</div> 