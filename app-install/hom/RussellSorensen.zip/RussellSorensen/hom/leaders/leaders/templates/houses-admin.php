<div id="lower-area">
    <h2>Manage Houses</h2>
    <p>Manage the important information of all houses</p>
    <p><a href="add-house.php" class="button"><span class="icon-house-plus"></span> Add a New House</a></p>
    <?php if ($houses) { ?>
    <div class="report-table">
        <?php foreach($houses as $k=>$v) { ?>
        <a href="edit-house.php?hid=<?php echo $v['house_id']; ?>" title="Edit <?php echo $v['name']; ?>" class="list-link<?php if ($k % 2 == 0) { ?> lighter<?php } ?>">
            <span class="icon-pencil list-link-control"></span>
            <?php echo $v['name']." - ".$v['address'].", ".$v['city'].", ".$v['state']." ".$v['zip']; ?>
        </a>
        <?php } ?>
        <p class="small post-info">There are <?php echo count($houses); ?> houses</p>
    </div>
    <?php } ?>
</div>  