<div id="lower-area">
    <h2><?php echo $house['name']; ?> House</h2>
    <p>These are your house details. Eventually you will be able to upload images and reports about your house.</p>
    <?php if ($success) { ?><p class="success"><?php echo $success['message']; ?></p><?php } ?>
    <?php if ($error) { ?><p class="error"><?php echo $error['message']; ?></p><?php } ?>
    <div>
        <div id="map-holder">
        <iframe src="https://www.google.com/maps/embed/v1/place?q=<?php echo $gmap_address; ?>&key=AIzaSyAN0om9mFmy1QN6Wf54tXAowK4eT0ZUPrU" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
        </div>
        <p>
        <?php echo $house['address']; ?><br/>
        <?php echo $house['city']; ?>, <?php echo $house['state']; ?> <?php echo $house['zip']; ?>
        </p>
    </div>
</div>