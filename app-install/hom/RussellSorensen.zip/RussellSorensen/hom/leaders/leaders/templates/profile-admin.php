<div id="lower-area">
    <h2>Edit your Account</h2>
    <p>Use this form to edit the details of your account</p>	
    <div class="main-form">
        <form method="post" action="process-profile.php" autocomplete="off">
            <input type="hidden" name="action" value="edit" />
            <input type="hidden" name="return_url" value="edit-profile.php" />
            <input type="hidden" name="user_id" value="<?php echo $user['user_id']; ?>" />
            <label>Email</label>
            <input type="email" name="email" value="<?php echo $user['email']; ?>" />
            <label>Password</label>
            <input type="password" name="password" />
            <input type="submit" value="Submit">
        </form>
    </div>
</div>