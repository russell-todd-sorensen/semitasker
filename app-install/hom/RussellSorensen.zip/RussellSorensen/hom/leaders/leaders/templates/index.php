<div id="lower-area">
    <h2>Good <?php echo $tod; ?><?php if ($user['display_name']) { ?>, <?php echo $user['display_name']; ?><?php } ?></h2>
    <p>&mdash;</p>
    <div id="icon-grid">
        <a href="manage-people.php" class="icon icon-border-b"><span class="icon-people"></span>People</a>
        <a href="view-house.php" class="icon icon-border-b icon-border-lr"><span class="icon-house"></span>House</a>
        <a href="manage-reports.php" class="icon icon-border-b"><span class="icon-files"></span>Reports</a>
        <a class="icon disabled"><span class="icon-messages"></span>Messages</a>
        <a href="view-documents.php" class="icon icon-border-lr"><span class="icon-documents"></span>Documents</a>
        <a href="edit-profile.php" class="icon"><span class="icon-profile"></span>Profile</a>
    </div>
</div>