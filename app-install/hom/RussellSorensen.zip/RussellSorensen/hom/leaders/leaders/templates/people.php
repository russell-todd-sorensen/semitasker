<div id="lower-area">
    <h2>Manage Participants</h2>
    <p>Update the important information of the participants in your house.</p>	
    <?php if ($house_members) { ?>
    <div class="report-table">
        <?php foreach($house_members as $k=>$v) { ?>
        <a href="edit-person.php?uid=<?php echo $v['user_id']; ?>" title="Edit <?php echo $v['first_name']." ".$v['last_name']; ?>" class="list-link<?php if ($k % 2 == 0) { ?> lighter<?php } ?>">
            <span class="icon-pencil list-link-control"></span>
            <?php echo $v['first_name']." ".$v['last_name']; ?>
        </a>
        <?php } ?>
        <p class="small post-info">There are <?php echo count($house_members); ?> active participants in your house</p>
    </div>
    <?php } ?>
    <?php if ($future_house_members) { ?>
    <div class="main-form">
        <br/>
        <fieldset>
            <legend>Future Participant<?php if (count($future_house_members)>1) {?>s<?php } ?></legend>
            <div class="report-table">
                <?php foreach($future_house_members as $k=>$v) { ?>
                <a href="edit-person.php?uid=<?php echo $v['user_id']; ?>" title="Edit <?php echo $v['first_name']." ".$v['last_name']; ?>" class="list-link<?php if ($k % 2 == 0) { ?> lighter<?php } ?>">
                    <span class="icon-pencil list-link-control"></span>
                    <?php echo $v['first_name']." ".$v['last_name']; ?> - Estimated Arrival: <?php echo date("M j, Y", strtotime($v['joined'])); ?>
                </a>
                <?php } ?>
            </div>
        </fieldset>
    </div>
    <?php } ?>
</div>  