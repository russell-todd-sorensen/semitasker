<div id="lower-area">
    <h2>Add report entry</h2>
    <p>Use this form to enter monthly report information on each of the participants in your house.</p>	
    <div class="main-form">
        <form method="post" action="process-report.php" autocomplete="off" id="report-form">
        	<input type="hidden" name="action" value="add" />
        	<input type="hidden" name="return_url" value="manage-reports.php" />
            <script type="text/javascript">
                $(document).ready( function () {
                    var reportType;
                    $("#report-type").on('change', function() {
                        //Advance to step two
                        $("#report-user").prop('disabled', false);
                        $("#report-user-label").addClass("label");
                        $("#report-user-label").removeClass("disabled-label");
                        reportType = $("#report-type").val();
                        if (reportType==1 || reportType==2) {
                            $("#comment-field").removeClass("hidden-field");
                            $("#failed-field").addClass("hidden-field");
                        }
                        else if (reportType==3 || reportType==4) {
                            $("#comment-field").addClass("hidden-field");
                            $("#failed-field").removeClass("hidden-field");
                        }
                    });
                    $("#report-user").on('change', function() {
                        //Advance to step three A
                        $("#report-month").prop('disabled', false);
                        $("#report-month-label").toggleClass("label disabled-label");
                    });
                    $("#report-month").on('change', function() {
                        //Advance to step three B
                        $("#report-day").prop('disabled', false);
                        $("#report-day-label").toggleClass("label disabled-label");
                    });
                    $("#report-day").on('change', function() {
                        //Advance to step four
                        $("#report-submit").prop('disabled', false);
                        
                        if (reportType==1 || reportType==2) {
                            $("#report-comment").prop('disabled', false).prop('required', true);
                            $("#report-comment-label").toggleClass("label disabled-label");
                        }
                                                                            
                        if (reportType==3 || reportType==4) {
                            $("#report-failed-false").prop('disabled', false).prop('required', true);
                            $("#report-failed-true").prop('disabled', false).prop('required', true);
                            $("#report-failed-label").toggleClass("label disabled-label");
                            $("#report-failed-false-label").toggleClass("label disabled-label");
                            $("#report-failed-true-label").toggleClass("label disabled-label");
                        }
                        if (reportType==3) {
                            $("#report-failed-false").on('change', function() {
                                $("#ua-result-field").addClass("hidden-field");
                            });
                            $("#report-failed-true").on('change', function() {
                                $("#ua-result-field").removeClass("hidden-field");
                            });
                        }
                    });
                });
            </script>
        
            <label>Report Entry Type</label>
            <select name="type" id="report-type" required>
                <option value="" selected disabled></option>
                <option value="1">Update</option>
                <option value="2">Violation</option>
                <option value="3">Urinalysis (UA) Test</option>
                <option value="4">Breathalyzer Test</option>
            </select>
            <label class="disabled-label" id="report-user-label">Participant</label>
            <select name="user" id="report-user" disabled>
                <option value="" selected disabled></option>
                <?php foreach($house_members as $k=>$v) { ?>
                <option value="<?php echo $v['user_id']; ?>"><?php echo $v['first_name']." ".$v['last_name']; ?></option>
                <?php } ?>
            </select>
            <div class="fl threefourths-left">
                <label class="disabled-label" id="report-month-label">Month</label>
                <select name="month" id="report-month" disabled>
                    <option value="" selected disabled></option>
                    <option value="<?php echo $this_month[0]; ?>-<?php echo $this_month[2]; ?>"><?php echo $this_month[1]; ?></option>
                    <option value="<?php echo $last_month[0]; ?>-<?php echo $last_month[2]; ?>"><?php echo $last_month[1]; ?></option>
                </select>
            </div>
            <div class="fr quarter-right">
                <label class="disabled-label" id="report-day-label">Day</label>
                <select name="day" id="report-day" disabled>
                    <option value="" selected disabled></option>
                    <?php for ($x=1; $x<=31; $x++) { ?>
                    <option value="<?php echo $x; ?>"><?php echo $x; ?></option>
                    <?php } ?>
                </select>
            </div>
            <div class="clearfix"></div> 
            <div id="failed-field" class="hidden-field">
                <label class="disabled-label" id="report-failed-label">Passed Test?</label>
                <input type="radio" name="failed" value="0" id="report-failed-false" disabled>
                <label for="report-failed-false" class="checkbox-label disabled-label" id="report-failed-false-label">Yes</label>
                &nbsp;&nbsp;
                <input type="radio" name="failed" value="1" id="report-failed-true" disabled>
                <label for="report-failed-true" class="checkbox-label disabled-label" id="report-failed-true-label">No</label>
            </div>
            <div id="ua-result-field" class="hidden-field">
                <label>Tested Positive For</label>
                <div class="cb-grid" id="ua-grid">
                    <div class="cb"><input type="checkbox" name="ua[]" value="thc" id="ua-thc"><label for="ua-thc" class="checkbox-label">THC</label></div>
                    <div class="cb"><input type="checkbox" name="ua[]" value="oxy" id="ua-oxy"><label for="ua-oxy" class="checkbox-label">OXY</label></div>
                    <div class="cb"><input type="checkbox" name="ua[]" value="benzo" id="ua-benzo"><label for="ua-benzo" class="checkbox-label">BENZO</label></div>
                    <div class="cb"><input type="checkbox" name="ua[]" value="coc" id="ua-coc"><label for="ua-coc" class="checkbox-label">COC</label></div>
                    <div class="cb"><input type="checkbox" name="ua[]" value="meth" id="ua-meth"><label for="ua-meth" class="checkbox-label">METH</label></div>
                    <div class="cb"><input type="checkbox" name="ua[]" value="opi" id="ua-opi"><label for="ua-opi" class="checkbox-label">OPI</label></div>
                    <div class="clearfix"></div>
                </div>
            </div> 
            <div id="comment-field" class="hidden-field">
                <label class="disabled-label" id="report-comment-label">Comment</label>
                <textarea name="comment" id="report-comment" disabled></textarea>
            </div>
            <input type="submit" value="Submit" id="report-submit" disabled>
        </form>
    </div>
</div>   