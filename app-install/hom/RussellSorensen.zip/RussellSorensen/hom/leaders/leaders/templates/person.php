<div id="lower-area">
    <h2>Editing - <?php echo $user['first_name'].' '.$user['last_name']; ?></h2>
    <p>Use this form to edit the details of this participant.</p>	
    <div class="main-form">
        <form method="post" action="process-person.php" autocomplete="off">
            <input type="hidden" name="action" value="edit" />
            <input type="hidden" name="return_url" value="edit-person.php" />
            <input type="hidden" name="user_id" value="<?php echo $user['user_id']; ?>" />
            <label>First Name</label>
            <input type="text" name="first_name" value="<?php echo $user['first_name']; ?>" />
            <label>Last Name</label>
            <input type="text" name="last_name" value="<?php echo $user['last_name']; ?>" />
            <label>Nick Name (Goes by)</label>
            <input type="text" name="nick_name" value="<?php echo $user['nick_name']; ?>" />
            <label>Phone</label>
            <input type="tel" name="phone" value="<?php echo $user['phone']; ?>" />
            <label>Email</label>
            <input type="email" name="email" value="<?php echo $user['email']; ?>" />
            <input type="submit" value="Submit">
        </form>
    </div>
    <?php if ($display_edited_data) { ?>
    <p class="small post-info">Last Edited: <?php echo date("M j, Y g:i a", strtotime($user['last_edited'])); ?> by <?php echo $user['last_edited_by']; ?></p>
    <?php } ?>
</div>