<div id="lower-area">
    <h2>Run Reports</h2>
    <p>Select a house or all houses and a date range to generate a report</p>
    <div class="main-form">
        <form method="post" autocomplete="off" action="export-report.php">
        	<input type="hidden" name="return_url" value="view-reports.php" />
            <label>House</label>
            <select name="house_id">
                <option value="0">All Houses</option>
                <?php foreach($houses as $k=>&$v) { ?>
                <option value="<?php echo $v['house_id']; ?>"<?php if ($current_house==$v['house_id']) { ?> selected<?php } ?>><?php echo $v['name']; ?></option>
                <?php } ?>
            </select>
            <label>Start Date</label>
            <input type="date" name="start" value="<?php echo $start; ?>" />
            <label>End Date</label>
            <input type="date" name="end" value="<?php echo $end; ?>" />
            <input type="submit" value="Generate Report">
        </form>
    </div>
</div>   