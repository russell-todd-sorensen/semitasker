<div id="lower-area">
    <h2><?php echo $content['title']; ?></h2>
    <p><?php echo $content['intro']; ?></p>	
    <div class="main-form">
        <form method="post" action="process-house.php" autocomplete="off">
            <input type="hidden" name="action" value="<?php echo $content['action']; ?>" />
            <input type="hidden" name="return_url" value="edit-house.php" />
            <input type="hidden" name="house_id" value="<?php echo $house['house_id']; ?>" />
            <label>House Name</label>
            <input type="text" name="name" value="<?php echo $house['name']; ?>" />
            <label>Address</label>
            <input type="text" name="address" value="<?php echo $house['address']; ?>" />
            <label>City</label>
            <input type="text" name="city" value="<?php echo $house['city']; ?>" />
            <label>State</label>
            <select name="state">
                <?php foreach ($states as $k=>$v) { ?>
                <option value="<?php echo $k; ?>"<?php if ($house['state']==$k) { ?> selected<?php } ?>><?php echo $v; ?></option>
                <?php } ?>
            </select>
            <label>Zip</label>
            <input type="text" name="zip" value="<?php echo $house['zip']; ?>" />
            <input type="submit" value="Submit">
        </form>
    </div>
    <br/>
    <?php if ($display_edited_data) { ?>
    <p class="small post-info">Last Edited: <?php echo date("M j, Y g:i a", strtotime($house['last_edited'])); ?> by <?php echo $house['last_edited_by']; ?></p>
    <?php } ?>
</div>