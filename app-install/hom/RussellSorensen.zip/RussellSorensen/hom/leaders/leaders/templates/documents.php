<div id="lower-area">
    <h2>Documents</h2>
    <p>These are important documents that you will need access to. All documents are in PDF, DOCX, or XLSX formats. If you cannot open any of these documents contact HOM administration.</p>
    <div>
        <?php if (@$document_types) { ?>
        <?php foreach($document_types as $k=>$v) { ?>
        <h3><?php echo $v['type']; ?></h3>
        <?php foreach($v['documents'] as $x=>$y) { ?>
        <a href="storage/<?php echo $y['document']; ?>" target="_blank" title="Download" class="list-link<?php if ($x % 2 == 0) { ?> lighter<?php } ?>">
            <span class="icon-download list-link-control"></span>
            <?php echo $y['name']; ?>
        </a>
        <?php } ?>        
        <?php } ?>
        <?php } ?>
    </div>
</div>