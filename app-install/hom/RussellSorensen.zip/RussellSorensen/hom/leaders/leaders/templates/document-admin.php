<div id="lower-area">
    <h2>Adding a New Document</h2>
    <p>Use this form to a new document to existing categories.</p>	
    <div class="main-form">
        <form method="post" enctype="multipart/form-data" action="process-document.php" autocomplete="off">
        	<input type="hidden" name="action" value="add" />
            <input type="hidden" name="return_url" value="manage-documents.php" />
            <label>Category</label>
            <select name="document_type_id">
                <?php foreach($document_types as $k=>&$v) { ?>
                <option value="<?php echo $v['type_id']; ?>"><?php echo $v['type']; ?></option>
                <?php } ?>
            </select>
            <label>Title</label>
            <input type="text" name="name" required />
            <label>File</label>
            <input type="file" name="document" required />
            <input type="submit" value="Submit">
        </form>
    </div>
</div>