<div id="lower-area">
    <h2>Documents</h2>
    <p>Upload documents for House Leaders to access. All documents should be uploaded in PDF, DOCX, or XLSX formats.</p>
    <p><a href="add-document.php" class="button"><span class="icon-document-plus"></span> Add a New Document</a></p> 
    <div>
        <?php if (@$document_types) { ?>
        <?php foreach($document_types as $k=>$v) { ?>
        <?php if ($v['documents']) { ?>
        <h3><?php echo $v['type']; ?></h3>
        <?php foreach($v['documents'] as $x=>$y) { ?>
        <div class="list-link<?php if ($x % 2 == 0) { ?> lighter<?php } ?>">
            <a href="process-document.php?did=<?php echo $y['document_id']; ?>&action=delete" title="Delete Document" onclick="return confirm('Are you sure you want to delete this document?')"><span class="icon-x-circle list-link-control"></span></a>
            <?php echo $y['name']; ?>
        </div>
        <?php } ?>
        <?php } ?>  
        <?php } ?>
        <?php } ?>
    </div>
</div>