<?php
include_once('inc/globals.config.php');

if (!isset($_SESSION['hom'])) {
	header('location: login.php');	
}

$db = new mysqli(DB_HOST, DB_USER, DB_PWD, DB_NAME);

/*------------------------------------------------
    GENERAL PROCESSING
------------------------------------------------*/

$now = date("Y-m-d H:i:s");

//Pull out email address for users table entry
$email = $_POST['email'];
unset($_POST['email']);

//Create single numeric string without special characters
$_POST['phone'] = preg_replace('/\D/', '', $_POST['phone']);

/*------------------------------------------------
    /END GENERAL PROCESSING
------------------------------------------------*/


/*------------------------------------------------
    ADD PHASE
------------------------------------------------*/

if ($_POST['action']=='add') {
	//Process all input data for safe insertion
	$entry_data = processForDBEntry($db, $_POST);
	
	//Create user
	$sql = "INSERT INTO users (email, role, created, created_by) VALUES('".$email."', '".$entry_data['role']."', '".$now."', '".$_SESSION['hom']['user']."')";
	$db->query($sql);
	
	//Get new user_id
	$user_id = $db->insert_id;
	
	//Create user_profile
	$sql = "INSERT INTO user_profiles (user_id, first_name, last_name, nick_name, supervision_number, phone, joined, driver, payment_arrangements, special_stipulations, program_status, program_status_notes, created, created_by) VALUES('".$user_id."', '".$entry_data['first_name']."','".$entry_data['last_name']."', '".$entry_data['nick_name']."', '".$entry_data['supervision_number']."', '".$entry_data['phone']."', '".$entry_data['joined']."', '".$entry_data['driver']."', '".$entry_data['payment_arrangements']."', '".$entry_data['special_stipulations']."', '".$entry_data['program_status']."', '".$entry_data['program_status_notes']."', '".$now."', '".$_SESSION['hom']['user']."')";
	$db->query($sql);
	
	//Create connection between user and house
	$sql = "INSERT INTO conn_user_to_house (house_id, user_id) VALUES('".$entry_data['house_id']."', '".$user_id."')";
	$db->query($sql);
	
	//Set messaging
	$_SESSION['hom']['message'] = array("success", "You added a new participant");
	
	//Redirect to manage page
	header('location: '.$_POST['return_url'].'?uid='.$user_id);
}

/*------------------------------------------------
    /END ADD PHASE
------------------------------------------------*/

/*------------------------------------------------
    EDIT PHASE
------------------------------------------------*/

if ($_POST['action']=='edit') {
	//Collect current user data to run comparison
	$sql = "SELECT * FROM user_profiles WHERE user_id='".$_POST['user_id']."'";
	$result = $db->query($sql);
	$user = $result->fetch_array(MYSQLI_ASSOC);
	
	//Combine the two to get a full merged entry for the database
	$merged_data = array_merge($user, $_POST);
	
	//Process all input data for safe insertion
	$entry_data = processForDBEntry($db, $merged_data);
	
	//Update user_profiles
	$sql = "UPDATE user_profiles SET first_name='".$entry_data['first_name']."', last_name='".$entry_data['last_name']."', nick_name='".$entry_data['nick_name']."', supervision_number='".$entry_data['supervision_number']."', phone='".$entry_data['phone']."', joined='".$entry_data['joined']."', driver='".$entry_data['driver']."', payment_arrangements='".$entry_data['payment_arrangements']."', special_stipulations='".$entry_data['special_stipulations']."', program_status='".$entry_data['program_status']."', program_status_notes='".$entry_data['program_status_notes']."', last_edited='".$now."', last_edited_by='".$_SESSION['hom']['user']."' WHERE user_id='".$entry_data['user_id']."'";
	$db->query($sql);
	
	//Update house connection
	if (@$entry_data['house_id']!=0) {
		$sql = "UPDATE conn_user_to_house SET house_id='".$entry_data['house_id']."' WHERE user_id='".$entry_data['user_id']."'";
		$db->query($sql);
	}
	
	//Second Step: Update users table with new email
	//Update users 
	if (@$entry_data['role']) {
		$sql = "UPDATE users SET email='".$email."', role='".$entry_data['role']."', last_edited='".$now."', last_edited_by='".$_SESSION['hom']['user']."' WHERE user_id='".$entry_data['user_id']."'";	
	}
	else {
		$sql = "UPDATE users SET email='".$email."', last_edited='".$now."', last_edited_by='".$_SESSION['hom']['user']."' WHERE user_id='".$entry_data['user_id']."'";	
	}
	$db->query($sql);
	
	//Set messaging
	$_SESSION['hom']['message'] = array("success", "You updated ".$merged_data['first_name']." ".$merged_data['last_name']."'s details");
	
	//Redirect to manage page
	header('location: '.$_POST['return_url'].'?uid='.$entry_data['user_id']);
}

/*------------------------------------------------
    /END EDIT PHASE
------------------------------------------------*/

/*------------------------------------------------
    DELETE PHASE
------------------------------------------------*/

if ($_REQUEST['action']=='delete') {
	if ($_SESSION['hom']['role']!=1) {
		//Set messaging
		$_SESSION['hom']['message'] = array("error", "You have do not have permissions for that action");
		
		header('location: '.BASE_URL);	
		
		break;
	}
	else {
		//Remove the entries
		$sql = "DELETE FROM conn_user_to_house WHERE user_id='".$_REQUEST['uid']."'";
		$db->query($sql);
		
		$sql = "DELETE FROM user_profiles WHERE user_id='".$_REQUEST['uid']."'";
		$db->query($sql);
		
		$sql = "DELETE FROM users WHERE user_id='".$_REQUEST['uid']."'";
		$db->query($sql);	
		
		//Set messaging
		$_SESSION['hom']['message'] = array("success", "You have removed this participant");
		
		header('location: manage-people.php');
	}
}

/*------------------------------------------------
    /END DELETE PHASE
------------------------------------------------*/

?>