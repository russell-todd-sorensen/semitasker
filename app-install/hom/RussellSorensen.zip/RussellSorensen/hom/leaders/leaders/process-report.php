<?php
include_once('inc/globals.config.php');

if (!isset($_SESSION['hom'])) {
	header('location: login.php');	
}

$db = new mysqli(DB_HOST, DB_USER, DB_PWD, DB_NAME);

/*------------------------------------------------
    ADD PHASE
------------------------------------------------*/

if ($_POST['action']=='add') {	
	$now = date("Y-m-d H:i:s");
	$date_parts = explode("-", $_POST['month']);
	$date = date("Y-m-d", strtotime($date_parts[1].'-'.$date_parts[0].'-'.$_POST['day']));
	$_POST['comment'] = mysqli_real_escape_string($db, $_POST['comment']);
	
	if ($_POST['type']==1 || $_POST['type']==2) {
		$_POST['failed'] = 0;	
	}
	
	if ($_POST['failed']==0) {
		$pass_fail = "Negative";	
	}
	else {
		$pass_fail = "Positive";		
	}
	
	if ($_POST['type']==3 || $_POST['type']==4) {
		if ($_POST['type']==3) {
			$type = "UA";	
		}
		else if ($_POST['type'] ==4) {
			$type = "Breathalyzer";	
		}
		$message = $type.": ".$pass_fail;
		if ($_POST['ua']) {
			$message .= " ";
			$loop = 0;
			$last = count($_POST['ua']);
			foreach ($_POST['ua'] as $k=>$v) {
				$message .= strtoupper($v);
				if ($loop<$last-1) {
					$message .= ", ";
					$loop++;	
				}
			}	
		}
		$_POST['comment'] = $message;
	}
	
	$sql = "INSERT INTO reports (user_id, type, date, comment, failed, created, created_by) VALUES('".$_POST['user']."', '".$_POST['type']."', '".$date."', '".$_POST['comment']."', '".$_POST['failed']."', '".$now."', '".$_SESSION['hom']['user']."')";
	
	$db->query($sql);
	
	//Set message
	$_SESSION['hom']['message'] = array("success", "You have added an entry");
	
	header('location: '.$_POST['return_url']);
}

/*------------------------------------------------
    /END ADD PHASE
------------------------------------------------*/

/*------------------------------------------------
    DELETE PHASE
------------------------------------------------*/

if ($_REQUEST['action']=='delete') {
	$sql = "SELECT house_id FROM conn_user_to_house WHERE user_id='".$_SESSION['hom']['user']."'";
	$result = $db->query($sql);
	$house = $result->fetch_array(MYSQLI_ASSOC);
	
	$sql = "SELECT * FROM reports LEFT JOIN conn_user_to_house ON reports.user_id=conn_user_to_house.user_id WHERE report_id='".$_REQUEST['rid']."'";
	$result = $db->query($sql);
	$report = $result->fetch_array(MYSQLI_ASSOC);
	
	//This admin has the rights to delete this record
	if ($house['house_id']==$report['house_id']) {
		$sql = "DELETE FROM reports WHERE report_id=".$report['report_id'];
		$db->query($sql);
	}
	
	//Set message
	$_SESSION['hom']['message'] = array("success", "You have removed an entry");
	
	header('location: manage-reports.php');
}

/*------------------------------------------------
    /END DELETE PHASE
------------------------------------------------*/

?>