<?php
include_once('inc/globals.config.php');

if (!isset($_SESSION['hom'])) {
	header('location: login.php');	
}

$db = new mysqli(DB_HOST, DB_USER, DB_PWD, DB_NAME);
$sql = "SELECT first_name, nick_name FROM user_profiles WHERE user_id='".$_SESSION['hom']['user']."'";
$result = $db->query($sql);
$user = $result->fetch_array(MYSQLI_ASSOC);

if (@$user['nick_name']) {
	$user['display_name'] = $user['nick_name'];	
}
else {
	$user['display_name'] = 	$user['first_name'];
}

$tod = date("G");
if ($tod>=0 && $tod<12) {
	$tod = "Morning";	
}
if ($tod>=12 && $tod<18) {
	$tod = "Afternoon";
}
if ($tod>=18) {
	$tod = "Evening";	
}
$page['id'] = 'Home';
$page['title'] = 'Welcome';
if ($_SESSION['hom']['role']==1) {
	$page['template'] = "index-admin.php";
}
else {
	$page['template'] = "index.php";	
}
?>

<?php include('header.php'); ?>
<div id="main">
	<div id="notifications"></div>
    <div id="search-bar">
    	<h2><!--<span class="icon-magnifying-glass"></span>Find Someone--></h2>
    </div>
    <?php include ('templates/'.$page['template']); ?>
</div>
<?php include('footer.php'); ?>