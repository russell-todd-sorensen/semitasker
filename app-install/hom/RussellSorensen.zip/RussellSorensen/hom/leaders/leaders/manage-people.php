<?php
include_once('inc/globals.config.php');

if (!isset($_SESSION['hom'])) {
	header('location: login.php');	
}

$db = new mysqli(DB_HOST, DB_USER, DB_PWD, DB_NAME);

$page['id'] = 'Manage-People';

/*------------------------------------------------
    ADMIN PAGE PROCESSING
------------------------------------------------*/

if ($_SESSION['hom']['role']==1) {
	if (!$_REQUEST['program_status']) {
		$program_status = 1;	
	}
	else {
		$program_status = $_REQUEST['program_status'];	
	}
	
	$sql = "SELECT * FROM user_profiles LEFT JOIN users ON user_profiles.user_id=users.user_id WHERE role!=1 AND program_status='".$program_status."' ORDER BY last_name, first_name ASC";
	$result = $db->query($sql);
	while ($row = $result->fetch_assoc()) {
		$participants[] = $row;
	}
	
	$page['title'] = 'Manage Participants';
	$page['template'] = "people-admin.php";
}

/*------------------------------------------------
    /END ADMIN PAGE PROCESSING
------------------------------------------------*/

/*------------------------------------------------
    GENERAL PAGE PROCESSING
------------------------------------------------*/

else {
	$sql = "SELECT house_id FROM conn_user_to_house WHERE user_id='".$_SESSION['hom']['user']."'";
	$result = $db->query($sql);
	$house = $result->fetch_array(MYSQLI_ASSOC);
	
	$current_date = date("Y-m-d");
	
	//Select ACTIVE house members
	$sql = "SELECT * FROM conn_user_to_house LEFT JOIN user_profiles ON conn_user_to_house.user_id=user_profiles.user_id LEFT JOIN users ON conn_user_to_house.user_id=users.user_id WHERE conn_user_to_house.house_id='".$house['house_id']."' AND conn_user_to_house.user_id!='".$_SESSION['hom']['user']."' AND (users.role='3' || users.role='4') AND user_profiles.program_status=1 AND joined<='".$current_date."' ORDER BY user_profiles.last_name ASC";	
	$result = $db->query($sql);
	while ($row = $result->fetch_assoc()) {
		$house_members[] = $row;
	}
	
	//Select future house members
	$sql = "SELECT * FROM conn_user_to_house LEFT JOIN user_profiles ON conn_user_to_house.user_id=user_profiles.user_id LEFT JOIN users ON conn_user_to_house.user_id=users.user_id WHERE conn_user_to_house.house_id='".$house['house_id']."' AND conn_user_to_house.user_id!='".$_SESSION['hom']['user']."' AND users.role='3' AND joined>='".$current_date."' ORDER BY user_profiles.last_name ASC";	
	$result = $db->query($sql);
	while ($row = $result->fetch_assoc()) {
		$future_house_members[] = $row;
	}
	
	$page['title'] = 'Manage my Participants';
	$page['template'] = "people.php";	
}

/*------------------------------------------------
    /END GENERAL PAGE PROCESSING
------------------------------------------------*/

?>

<?php include('header.php'); ?>
<div id="main">
	<div id="notifications"></div>
    <div id="search-bar">
    	<h2><!--<span class="icon-magnifying-glass"></span>Find Someone--></h2>
    </div>
    <?php include ('templates/'.$page['template']); ?>
</div>
<?php include('footer.php'); ?>