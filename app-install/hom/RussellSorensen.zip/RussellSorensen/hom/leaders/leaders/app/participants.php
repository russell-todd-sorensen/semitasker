<?php
include_once('./php-local-include.php');

if (!isset($_SESSION['hom'])) {
	header('location: /login.php');
	error_log("Attempt to access while not logged in.");
}

if ($_SESSION['hom']['role']==1) {
    error_log("Returning participants.php to admin user");
?><!DOCTYPE HTML>
<html lang="en_US">
<head>
<meta charset="utf-8">
<meta base="http://hom1:8080/" />
<meta name="viewport" content="width=device-width, initial-scale=0.775 maximum-scale=1.0">
<title>Participants</title>
<link rel="stylesheet" type="text/css" media="all" href="css/reset.css">

<link rel="stylesheet" media="all" href="css/log.css">
<link rel="stylesheet" media="all" href="js/jQuery.UI.Combined.1.8.20.1/Content/Content/themes/base/jquery.ui.all.css">
<link rel="stylesheet" media="all" href="css/logo-maker-1.css">
<link rel="stylesheet" media="all" href="css/green-form.css" >
<link rel="stylesheet" media="all" href="https://file.myfontastic.com/xXW5U9UCxPBxcUuaZGbBJP/icons.css">
<style type="text/css">

body, html {
    padding: 0;
    margin: -3px;
    width: 450px;
    font-family: "Lucida Sans Unicode", "Lucida Grande", sans-serif;
}

/* override #panel  styles */
#panel {
    padding: 0;
    margin: 0;
}
#panel fieldset {
    border-width: 2px;
    width: 458px;
    font-family: "Lucida Sans Unicode", "Lucida Grande", sans-serif;
    font-size: 1.2em;
}
#panel h3 {
    width: 99%;
    padding: 3px;
    background-color: rgba(0,0,0,.1);
}

#panel h3 span {
    margin: auto;
    padding: 0;
    display: block;
    width: 40%;
}

#panel input,
#panel input[type="range"] {
    display: inline-block;
    width: 280px;
    height: 1.0em;
    font-size: 1.5em;
    font-family: "Lucida Sans Unicode", "Lucida Grande", sans-serif;
    color: darkolivegreen;
}

#panel li.expand span {
    display: inline-block;
    width: 4em;
    text-align: right;
    font-family: "Lucida Sans Unicode", "Lucida Grande", sans-serif;
}

#panel select {
    width: 283px;
    height: 1.5em;
    font-family: "Lucida Sans Unicode", "Lucida Grande", sans-serif;
}

.cust {
    list-style: none;
    cursor: pointer;
    width: 445px;
    padding-top: 2px;
    padding-left: 3px;
    color: #202b0d; /*#364817; */
}
.cust:focus {
    background-color: #d3d3d3;
    border: 2px solid darkolivegreen;
    outline-color: darkolivegreen;
}

.icon-people:before {
  content: "\65\09\09 ";
  vertical-align: -2px;
  color: darkolivegreen;
}

#container {
    vertical-align: top;
    padding: 0;
    margin: 0;
}

#selection, 
#profile {
    display: inline-block;
    width: 450px;
    vertical-align: top;
    padding-left: 8px;
    margin-left: 5px;
    margin-top: 3px;
}

#profile {
    background-color: #d3d3d3;
    border: solid darkolivegreen 2px;
}
#profile label {
    font-weight: bold;
    vertical-align: top;
}
#profile pre {
    display: inline-block;
}

.active {
    font-weight: normal;
}

.notActive {
    font-weight: bold;
    color: #FF0000;
}
.notActive:before {
    content: 'Not Active:';
    color: black;
}

#accountTable {
    margin-left: 4px;
    width: 440px;
    border-collapse: collapse;

}
#accountTable td,
#accountTable th {
    border: 1px solid black;
}

#accountTable span.positive {
    color: darkgreen;
    font-weight: bold;
}
#accountTable legend {
    background-color: silver;
}
#accountTable span.negative {
    color: darkred;
    font-weight: bold;
}
#accountTable th {
    background-color: #aaa;
}
#accountTable td {
    text-align: right;
}

#accountTable tr:nth-child(odd) {
    background-color: #ccc;
}
#lastTransaction #accountTable {
    width: 440px;
    font-size: .9em;
}
.notes {
    width: 440px;
    font-size: .9em;
}
@media only screen and ((max-device-width: 450px) or (max-width: 450px)) {
        /*body, html, #container {
            width: 450px;
        } */

		div#header {
			background-image: url(media-queries-phone.jpg);
			height: 93px;
			position: relative;
		}

		div#header h1 {
			font-size: 140%;
		}

		#content {
			float: none;
			width: 100%;
		}

		#navigation {
			float:none;
			width: auto;
		}
		
		@-ms-viewport {
		    width:450px;
		}
}
</style>

<script type="text/javascript" src="https://d3js.org/d3.v4.js"></script>
<script type="text/javascript" src="js/jquery-1.7.1.js"></script>
<script type="text/javascript" src="js/jQuery.UI.Combined.1.8.20.1/Content/Scripts/jquery-ui-1.8.20.js"></script>
<script type="text/javascript" src="js/log-2.js"></script>
<script type="text/javascript" src="js/data.js"></script>
<script type="text/javascript" src="js/form-save-restore.js"></script>
<script type="text/javascript" src="js/binary-hex-conversions.js"></script>
<script type="text/javascript" src="js/example-library.js"></script>
<script type="text/javascript" src="js/svg-transform.js"></script>
<script type="text/javascript" src="js/participants.js"></script>

<script>

$(document).ready(function() {

    console.log("Starting to get data");
    loadXHRFile("./data/all-customer-data.IIF",getCustomerIIF);
    loadXHRFile("./data/other-name-list.IIF",getOtherNamesIIF);
    loadXHRFile("./data/customer-data-with-balances.csv",getCustomerWithBalancesCSV);
    loadXHRFile("./data/sales-reps.IIF",getSalesRepsIIF);
    loadXHRFile("./data/customer-transactions.csv",getCustomerTransactionsCSV);
    Log.Hide();
});
</script>

</head>
<body>

<form id="panel" onSubmit="javascript:return false;">
<fieldset>
<h3><span>Participant Search</span></h3>
<ul>
 <li><label for="fieldToSearch">Search Field:</label>
 <select id="fieldToSearch" tabIndex="7"
  onChange="Customer.configureSearchField('fieldToSearch')">
   <option value="search">All Fields</option>
   <option value="name">Name</option>
   <option value="doc">DOC #</option>
   <option value="cco">CCO</option>
   <option value="house">House</option>
   <option value="voucher">Voucher</option>
   <option value="ctype">Program Role</option>
   <option value="dob">Birthdate</option>
   <option value="notes">Notes</option>
  </select>
  </li>
 <li><label for="searchList">List:</label>
 <select id="searchList" name="searchList"  tabIndex="8"
  onChange="Customer.configureSearchList('searchList')">
   <option value="active" selected="selected">Active</option>
   <option value="all">All</option>
  </select>
  </li>
  <li><label for="outputType">Output Type</label>
  <select id="outputType" name="outputType" tabIndex="7"
   onChange="Customer.configureOutputType('outputType')">
    <option value="list" selected>Link List</option>
    <option value="csv">CSV/Database</option>
    <option value="csv-all">CSV/Database for Web</option>
  </select>
  </li>
  <li><label for="searchTerms">Search For:</label>
  <input type="text" id="searchTerms" name="searchTerms" tabIndex="9"
   onKeyUp="Customer.search('searchTerms','#selection');" />
  </li>
 </ul>
 </fieldset>

</form>
<div id="container">
<div id="selection"></div>
<div id="profile"></div>
</div>
</body>
</html><?php
} 
else {
	//This page is not for non admin users	
	error_log('Attempt to access while not logged in as admin.');
	header('location: /index.php');	
}
?>
