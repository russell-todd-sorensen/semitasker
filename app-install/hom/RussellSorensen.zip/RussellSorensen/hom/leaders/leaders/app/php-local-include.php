<?php

ini_set("log_errors", 1);
ini_set("error_log", "/kunden/homepages/12/d420142412/htdocs/leaders/app/logs/php-error.log");
error_log("running /app/php-local-include.php");

include_once('../inc/globals.config.php');

?>