<?php

include_once('php-local-include.php');

if (!isset($_SESSION['hom'])) {
    error_log('Attempt to run /app/php-info.php without session');
	header('location: /login.php');	
} else {
    error_log( "Running phpinfo()" );
    phpinfo(); 
}
?>