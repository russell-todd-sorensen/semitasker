<?php
session_start();
unset($_SESSION['hom']);

if(session_destroy()) {
	header("Location: login.php");
}
?>