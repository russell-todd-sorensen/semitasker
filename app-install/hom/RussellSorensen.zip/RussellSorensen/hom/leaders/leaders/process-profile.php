<?php
include_once('inc/globals.config.php');

if (!isset($_SESSION['hom'])) {
	header('location: login.php');	
}

$db = new mysqli(DB_HOST, DB_USER, DB_PWD, DB_NAME);

/*------------------------------------------------
    GENERAL PROCESSING
------------------------------------------------*/

$now = date("Y-m-d H:i:s");

//Pull out email address and password for second step entry
$email = $_POST['email'];
unset($_POST['email']);
$password = $_POST['password'];
unset($_POST['password']);

//Create single numeric string without special characters
$_POST['phone'] = preg_replace('/\D/', '', $_POST['phone']);

/*------------------------------------------------
    /END GENERAL PROCESSING
------------------------------------------------*/


/*------------------------------------------------
    EDIT PHASE
------------------------------------------------*/

if ($_POST['action']=='edit') {
	//Collect current user data to run comparison
	$sql = "SELECT * FROM user_profiles WHERE user_id='".$_POST['user_id']."'";
	$result = $db->query($sql);
	$user = $result->fetch_array(MYSQLI_ASSOC);
	
	//Reserve created for password
	$created = $user['created'];
	
	//Unset created, created_by, last_edited, last_edited_by for clean merge
	unset($user['created']);
	unset($user['created_by']);
	unset($user['last_edited']);
	unset($user['last_edited_by']);
	
	//Combine the two to get a full merged entry for the database
	$merged_data = array_merge($user, $_POST);
	
	//Process all input data for safe insertion
	$entry_data = processForDBEntry($db, $merged_data);
	
	//Update user_profiles
	$sql = "UPDATE user_profiles SET first_name='".$entry_data['first_name']."', last_name='".$entry_data['last_name']."', nick_name='".$entry_data['nick_name']."', supervision_number='".$entry_data['supervision_number']."', phone='".$entry_data['phone']."', joined='".$entry_data['joined']."', driver='".$entry_data['driver']."', payment_arrangements='".$entry_data['payment_arrangements']."', special_stipulations='".$entry_data['special_stipulations']."', program_status='".$entry_data['program_status']."', program_status_notes='".$entry_data['program_status_notes']."', last_edited='".$now."', last_edited_by='".$_SESSION['hom']['user']."' WHERE user_id='".$entry_data['user_id']."'";
	$db->query($sql);
	
	//Second Step: Update users table with new email and/or password
	//Update users 
	$sql = "UPDATE users SET email='".$email."', last_edited='".$now."', last_edited_by='".$_SESSION['hom']['user']."' WHERE user_id='".$entry_data['user_id']."'";
	$db->query($sql);
	
	if ($password!='') {
		if (strlen($password)<6) {
			//Set messaging
			$_SESSION['hom']['message'] = array("error", "Your password must be at least 6 characters");
			
			//Redirect to edit page
			header('location: '.$_POST['return_url']);
			
			break;
		}
		else {
			$sql = "SELECT created FROM users WHERE user_id='".$_SESSION['hom']['user']."'";
			$result = $db->query($sql);
			$user = $result->fetch_array(MYSQLI_ASSOC);
			
			//Encode new password
			$password = sha1($password.$user['created']);
			$sql = "UPDATE users SET password='".$password."' WHERE user_id='".$_SESSION['hom']['user']."'";
			$db->query($sql);
		}
	}
	
	//Set messaging
	$_SESSION['hom']['message'] = array("success", "You updated your profile");
	
	//Redirect to edit page
	header('location: '.$_POST['return_url']);
}

/*------------------------------------------------
    /END EDIT PHASE
------------------------------------------------*/


?>