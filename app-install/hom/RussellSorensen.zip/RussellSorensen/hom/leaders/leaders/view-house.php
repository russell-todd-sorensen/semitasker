<?php
include_once('inc/globals.config.php');

if (!isset($_SESSION['hom'])) {
	header('location: login.php');	
}

$db = new mysqli(DB_HOST, DB_USER, DB_PWD, DB_NAME);

$page['id'] = 'View-House';

/*------------------------------------------------
    GENERAL PAGE PROCESSING
------------------------------------------------*/

$sql = "SELECT house_id FROM conn_user_to_house WHERE user_id='".$_SESSION['hom']['user']."'";
$result = $db->query($sql);
$house = $result->fetch_array(MYSQLI_ASSOC);

$sql = "SELECT * FROM houses WHERE house_id='".$house['house_id']."'";
$result = $db->query($sql);
$house = $result->fetch_array(MYSQLI_ASSOC);

$address = preg_replace("/[\+]/", " ", $house['address']);
$gmap_address = $address.','.$house['city'].','.$house['state'].','.$house['zip'];
	
	
$page['title'] = $house['name']." House";
$page['template'] = "house.php";	


/*------------------------------------------------
    /END GENERAL PAGE PROCESSING
------------------------------------------------*/

?>

<?php include('header.php'); ?>
<div id="main">
	<div id="notifications"></div>
    <div id="search-bar">
    	<h2><!--<span class="icon-magnifying-glass"></span>Find Someone--></h2>
    </div>
    <?php include ('templates/'.$page['template']); ?>
</div>
<?php include('footer.php'); ?>