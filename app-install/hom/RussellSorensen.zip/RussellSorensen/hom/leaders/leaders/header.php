<?php 
/* HEADER TEMPLATE */
?>
<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title><?php echo $page['title'] ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex">
<link rel="icon" href="img/favicon.png" type="image/x-icon" />
<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700" rel="stylesheet" type="text/css">
<link href="https://file.myfontastic.com/xXW5U9UCxPBxcUuaZGbBJP/icons.css" rel="stylesheet">
<link href="css/main.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="https://code.jquery.com/jquery-3.1.0.min.js"></script>
<script type="text/javascript" src="js/main.js"></script>
<?php if ($page['header_includes']) { echo $page['header_includes']; } ?>
</head>
<body>
<?php if ($_SESSION['hom']['message']) { ?>
<div id="success-error">
	<p class="<?php echo $_SESSION['hom']['message'][0]; ?>"><?php echo $_SESSION['hom']['message'][1]; ?></p>
</div>
<?php $_SESSION['hom']['message'] = ""; ?>
<?php } ?>
<div id="top-bar">
	<?php if ($page['id']!='Home' && $page['id']!='Login') { ?><a href="<?php echo BASE_URL; ?>"><img src="img/logo.png" width="60"/></a><?php } else { ?><img src="img/logo.png" width="60" /><?php } ?>
    <?php if (isset($_SESSION['hom'])) { ?>	
	<div class="quick-links">
		<?php if ($page['id']!='Home') { ?><a href="<?php if ($page['backlink']) { echo $page['backlink']; } else { echo BASE_URL; } ?>"><span class="icon-arrow-left"></span> Back</a> | <?php } ?><a href="logout.php">Log Out</a>
    </div>
    <?php } ?>
</div>
