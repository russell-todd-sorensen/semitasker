<?php
include_once('inc/globals.config.php');

if (!isset($_SESSION['hom'])) {
	header('location: login.php');	
}

$db = new mysqli(DB_HOST, DB_USER, DB_PWD, DB_NAME);

$page['id'] = 'Add-Report';

/*------------------------------------------------
    GENERAL PAGE PROCESSING
------------------------------------------------*/

$sql = "SELECT house_id FROM conn_user_to_house WHERE user_id='".$_SESSION['hom']['user']."'";
$result = $db->query($sql);
$house = $result->fetch_array(MYSQLI_ASSOC);
$sql = "SELECT * FROM conn_user_to_house LEFT JOIN user_profiles ON conn_user_to_house.user_id=user_profiles.user_id LEFT JOIN users ON conn_user_to_house.user_id=users.user_id WHERE conn_user_to_house.house_id='".$house['house_id']."' AND conn_user_to_house.user_id!='".$_SESSION['hom']['user']."' AND (users.role='3' OR users.role='4') AND user_profiles.program_status='1' ORDER BY user_profiles.last_name ASC";	
$result = $db->query($sql);
while ($row = $result->fetch_assoc()) {
	$house_members[] = $row;
}

$this_month = array(date("m"), date("F"), date("Y"), date("Y-m-d"));
$last_month = array(date("m", strtotime("-1 month")), date("F", strtotime("-1 month")), date("Y", strtotime("-1 month")), date("Y-m-d", strtotime("-1 month")));


$page['title'] = 'Add Entry';
$page['template'] = "report.php";	


/*------------------------------------------------
    /END GENERAL PAGE PROCESSING
------------------------------------------------*/

?>

<?php include('header.php'); ?>
<div id="main">
	<div id="notifications"></div>
    <div id="search-bar">
    	<h2><!--<span class="icon-magnifying-glass"></span>Find Someone--></h2>
    </div>
    <?php include ('templates/'.$page['template']); ?>
</div>
<?php include('footer.php'); ?>