<?php
include_once('inc/globals.config.php');

if (!isset($_SESSION['hom'])) {
	header('location: login.php');	
}

$db = new mysqli(DB_HOST, DB_USER, DB_PWD, DB_NAME);

$page['id'] = 'Documents';

/*------------------------------------------------
    GENERAL PAGE PROCESSING
------------------------------------------------*/

$sql = "SELECT * FROM document_types ORDER BY type ASC";	
$result = $db->query($sql);
while ($row = $result->fetch_assoc()) {
	$document_types[] = $row;
}

if (@$document_types) {
	foreach($document_types as $k=>$v) {
		$sql = "SELECT * FROM documents WHERE document_type_id='".$v['type_id']."' ORDER BY name ASC";
		$result = $db->query($sql);
		while ($row = $result->fetch_assoc()) {
			$document_types[$k]['documents'][] = $row;
		}
	}
}
	
	
$page['title'] = "Important Documents";
$page['template'] = "documents.php";	


/*------------------------------------------------
    /END GENERAL PAGE PROCESSING
------------------------------------------------*/

?>

<?php include('header.php'); ?>
<div id="main">
	<div id="notifications"></div>
    <div id="search-bar">
    	<h2><!--<span class="icon-magnifying-glass"></span>Find Someone--></h2>
    </div>
    <?php include ('templates/'.$page['template']); ?>
</div>
<?php include('footer.php'); ?>