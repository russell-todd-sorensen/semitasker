document.addEventListener("DOMContentLoaded", function(event) { 
	//Check for success or error window
	var success_error = document.getElementById("success-error");
	if (success_error) {	
		setTimeout(showSuccessError, 250);
	}
	
	function showSuccessError() {
		success_error.classList.add("visible");	
		setTimeout(hideSuccessError, 5000);
	}
	
	function hideSuccessError() {
		success_error.classList.add("hidden");	
	}
});