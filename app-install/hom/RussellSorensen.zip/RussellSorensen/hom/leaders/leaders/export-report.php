<?php
include_once('inc/globals.config.php');

if (!isset($_SESSION['hom'])) {
	header('location: login.php');	
}

if ($_SESSION['hom']['role']!=1) {
	header('location: index.php');	
}

$db = new mysqli(DB_HOST, DB_USER, DB_PWD, DB_NAME);

$start = date("Y-m-01");
$end = date("Y-m-t");

if (@$_POST) {
	$start = $_POST['start'];
	$end = $_POST['end'];
	
	if ($_POST['house_id']==0) {
		$sql = "SELECT conn_user_to_house.user_id, users.role, user_profiles.first_name, user_profiles.last_name, houses.name AS house_name FROM conn_user_to_house LEFT JOIN users ON conn_user_to_house.user_id=users.user_id LEFT JOIN user_profiles ON conn_user_to_house.user_id=user_profiles.user_id LEFT JOIN houses ON conn_user_to_house.house_id=houses.house_id WHERE role='3'";
		$filename = "All-Houses-".$_POST['start']."-to-".$_POST['end'].".csv";
	}
	else {	
		$sql = "SELECT name FROM houses WHERE house_id='".$_POST['house_id']."'";
		$result = $db->query($sql);
		$house = $result->fetch_array(MYSQLI_ASSOC);
	
		$sql = "SELECT conn_user_to_house.user_id, users.role, user_profiles.first_name, user_profiles.last_name, houses.name AS house_name FROM conn_user_to_house LEFT JOIN users ON conn_user_to_house.user_id=users.user_id LEFT JOIN user_profiles ON conn_user_to_house.user_id=user_profiles.user_id LEFT JOIN houses ON conn_user_to_house.house_id=houses.house_id WHERE conn_user_to_house.house_id='".$_POST['house_id']."' AND role='3'";
		$filename = $house['name']."-".$_POST['start']."-to-".$_POST['end'].".csv";
	}
	$result = $db->query($sql);
	while ($row = $result->fetch_assoc()) {
		$participants[] = $row;
	}
	
	$report_data = [];
	foreach ($participants as $k=>&$v) {
		$sql = "SELECT * FROM reports WHERE user_id='".$v['user_id']."' AND date>='".$start."' AND date<='".$end."' ORDER BY date DESC";
		$result = $db->query($sql);
		while ($row = $result->fetch_assoc()) {
			$row['name'] = $v['last_name'].', '.$v['first_name'];
			$row['house_name'] = $v['house_name'];
			$report_data[] = $row;
		}
	}
	
	if (@$report_data) {
		function date_compare($a, $b) {
			$t1 = strtotime($a['date']);
			$t2 = strtotime($b['date']);
			return $t1 - $t2;
		}    
		usort($report_data, 'date_compare');	
		
		$report_csv_data = [];
		$report_csv_data[] = array("Entry ID", "Date", "Comment", "Name", "Violation", "House", "Written On");
		foreach($report_data as $k=>$v) {
			$violation = "";
			if ($v['type']==2 || $v['failed']) {
				$violation = "X";	
			}
			
			$report_csv_data[] = array($v['report_id'], $v['date'], $v['comment'], $v['name'], $violation, $v['house_name'], date("Y-m-d", strtotime($v['created'])));
		}		
		
		header("Content-Type: text/csv");
		header("Content-Disposition: attachment; filename=".$filename);
		// Disable caching
		header("Cache-Control: no-cache, no-store, must-revalidate"); // HTTP 1.1
		header("Pragma: no-cache"); // HTTP 1.0
		header("Expires: 0"); // Proxies
		
		function outputCSV($data) {
			$output = fopen("php://output", "w");
			foreach ($data as $row) {
				fputcsv($output, $row); // here you can change delimiter/enclosure
			}
			fclose($output);
		}
		
		outputCSV($report_csv_data);
	}
	else {
		$_SESSION['hom']['message'] = array("error", "There were no entries in the provided date range");
		
		header('location: '.$_POST['return_url']);
	}
}

?>