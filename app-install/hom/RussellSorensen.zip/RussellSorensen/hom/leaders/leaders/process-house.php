<?php
include_once('inc/globals.config.php');

if (!isset($_SESSION['hom'])) {
	header('location: login.php');	
}

$db = new mysqli(DB_HOST, DB_USER, DB_PWD, DB_NAME);

/*------------------------------------------------
    ADD PHASE
------------------------------------------------*/

if ($_POST['action']=='add') {	
	$now = date("Y-m-d H:i:s");
	
	//Process all input data for safe insertion
	$entry_data = processForDBEntry($db, $_POST);
	
	$sql = "INSERT INTO houses (name, address, city, state, zip, created, created_by) VALUES('".$entry_data['name']."', '".$entry_data['address']."', '".$entry_data['city']."', '".$entry_data['state']."', '".$entry_data['zip']."', '".$now."', '".$_SESSION['hom']['user']."')";
	$db->query($sql);
	
	//Get new house_id
	$house_id = $db->insert_id;
	
	//Set message
	$_SESSION['hom']['message'] = array("success", "You have added a house");
	
	header('location: '.$_POST['return_url'].'?hid='.$house_id);
}

/*------------------------------------------------
    /END ADD PHASE
------------------------------------------------*/

/*------------------------------------------------
    EDIT PHASE
------------------------------------------------*/

if ($_POST['action']=='edit') {	
	$now = date("Y-m-d H:i:s");
	
	//Process all input data for safe insertion
	$entry_data = processForDBEntry($db, $_POST);
	
	$sql = "UPDATE houses SET name='".$entry_data['name']."', address='".$entry_data['address']."', city='".$entry_data['city']."', state='".$entry_data['state']."', zip='".$entry_data['zip']."', last_edited='".$now."', last_edited_by='".$_SESSION['hom']['user']."' WHERE house_id='".$entry_data['house_id']."'";
	$db->query($sql);
	
	//Set message
	$_SESSION['hom']['message'] = array("success", "You have updated ".$entry_data['name']."'s details");
	
	header('location: '.$_POST['return_url'].'?hid='.$entry_data['house_id']);
}

/*------------------------------------------------
    /END EDIT PHASE
------------------------------------------------*/

/*------------------------------------------------
    DELETE PHASE
------------------------------------------------*/

if ($_REQUEST['action']=='delete') {
	//Delete functions here
}

/*------------------------------------------------
    /END DELETE PHASE
------------------------------------------------*/

?>