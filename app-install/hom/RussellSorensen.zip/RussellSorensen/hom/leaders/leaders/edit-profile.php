<?php
include_once('inc/globals.config.php');

if (!isset($_SESSION['hom'])) {
	header('location: login.php');	
}

$db = new mysqli(DB_HOST, DB_USER, DB_PWD, DB_NAME);

$sql = "SELECT * FROM user_profiles LEFT JOIN users ON user_profiles.user_id=users.user_id WHERE users.user_id='".$_SESSION['hom']['user']."'";
$result = $db->query($sql);
$user = $result->fetch_array(MYSQLI_ASSOC);

if ($user['phone']) {
	$user['phone'] = "(".substr($user['phone'], 0, 3).") ".substr($user['phone'], 3, 3)."-".substr($user['phone'],6);	
}
else {
	$user['phone'] = "";
}

$page['id'] = 'Profile';
$page['title'] = 'Editing Your Profile';
if ($_SESSION['hom']['role']==1) {
	$page['template'] = "profile-admin.php";
}
else {
	$page['template'] = "profile.php";	
}
?>

<?php include('header.php'); ?>
<div id="main">
	<div id="notifications"></div>
    <div id="search-bar">
    	<h2><!--<span class="icon-magnifying-glass"></span>Find Someone--></h2>
    </div>
    <?php include ('templates/'.$page['template']); ?>
</div>
<?php include('footer.php'); ?>