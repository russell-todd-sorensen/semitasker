<?php
include_once('inc/globals.config.php');

if (!isset($_SESSION['hom'])) {
	header('location: login.php');	
}

$db = new mysqli(DB_HOST, DB_USER, DB_PWD, DB_NAME);

$page['id'] = 'Edit-House';

/*------------------------------------------------
    ADMIN PAGE PROCESSING
------------------------------------------------*/

if ($_SESSION['hom']['role']==1) {	
	include_once('inc/states.inc.php');
	
	$sql = "SELECT * FROM houses WHERE house_id='".$_REQUEST['hid']."'";
	$result = $db->query($sql);
	$house = $result->fetch_array(MYSQLI_ASSOC);
	
	$last_edited_by = $house['last_edited_by'];
	
	//Get last edited by info
	if ($last_edited_by) {
		$sql = "SELECT first_name, last_name FROM user_profiles WHERE user_id='".$last_edited_by."'";
		$result = $db->query($sql);
		$last_edited_by = $result->fetch_array(MYSQLI_ASSOC);
		$house['last_edited_by'] = $last_edited_by['first_name']." ".$last_edited_by['last_name'];
		$display_edited_data = true;
	}
	
	$content['title'] = 'Editing - '.$house['name'];
	$content['intro'] = 'Use this form to edit the details of this house.';
	$content['action'] = 'edit';
	
	$page['title'] = 'Editing - '.$house['name'];
	$page['template'] = "house-admin.php";
	$page['backlink'] = "manage-houses.php";
}

/*------------------------------------------------
    /END ADMIN PAGE PROCESSING
------------------------------------------------*/

/*------------------------------------------------
    GENERAL PAGE PROCESSING
------------------------------------------------*/

else {
	//This page is not for non admin users
	if ($_SESSION['hom']['role']!=1) {
		header('location: index.php');	
	}
}

/*------------------------------------------------
    /END GENERAL PAGE PROCESSING
------------------------------------------------*/

?>

<?php include('header.php'); ?>
<div id="main">
	<div id="notifications"></div>
    <div id="search-bar">
    	<h2><!--<span class="icon-magnifying-glass"></span>Find Someone--></h2>
    </div>
    <?php include ('templates/'.$page['template']); ?>
</div>
<?php include('footer.php'); ?>