<?php
include_once('inc/globals.config.php');

if (!isset($_SESSION['hom'])) {
	header('location: login.php');	
}

$db = new mysqli(DB_HOST, DB_USER, DB_PWD, DB_NAME);

/*------------------------------------------------
    GENERAL PROCESSING
------------------------------------------------*/

$now = date("Y-m-d H:i:s");

/*------------------------------------------------
    /END GENERAL PROCESSING
------------------------------------------------*/

/*------------------------------------------------
    ADD PHASE
------------------------------------------------*/

if ($_POST['action']=='add') {
	if ($_FILES['document']['error']==0) {		
		$name = processForDBEntry($db, $_POST['name']);
		
		$path_parts = pathinfo($_FILES['document']['name']);
		$extension = $path_parts['extension'];
		$file = uniqid().".".$extension;
		if (move_uploaded_file($_FILES['document']['tmp_name'], "storage/".$file)) {	
			//Process document name for single quote issues
			$name = processForDBEntry($db, $_POST['name']);
		
			$sql = "INSERT INTO documents (document_type_id, document, name, created, created_by) VALUES('".$_POST['document_type_id']."', '".$file."', '".$name."', '".$now."', '".$_SESSION['hom']['user']."')";
			$result = $db->query($sql);
			
			//Set messaging
			$_SESSION['hom']['message'] = array("success", "You added a document");
		}
		else {
			//Set messaging
			$_SESSION['hom']['message'] = array("error", "There was a problem with the uploaded document");
		}
	}
	else {
		//No file uploaded	
		//Set messaging
		$_SESSION['hom']['message'] = array("error", "You must upload a document");
		
		//Redirect to manage page
		header('location: add-document.php');
		
		break;
	}
	//Redirect to manage page
	header('location: '.$_POST['return_url']);
}

/*------------------------------------------------
    /END ADD PHASE
------------------------------------------------*/

/*------------------------------------------------
    EDIT PHASE
------------------------------------------------*/

if ($_POST['action']=='edit') {
	//Add edit phase processing if applicable
}

/*------------------------------------------------
    /END EDIT PHASE
------------------------------------------------*/

/*------------------------------------------------
    DELETE PHASE
------------------------------------------------*/

if ($_REQUEST['action']=='delete') {
	if ($_SESSION['hom']['role']!=1) {
		//Set messaging
		$_SESSION['hom']['message'] = array("error", "You have do not have permissions for that action");
		
		header('location: '.BASE_URL);	
		
		break;
	}
	else {
		$sql = "SELECT * FROM documents WHERE document_id='".$_REQUEST['did']."'";
		$result = $db->query($sql);
		$document = $result->fetch_array(MYSQLI_ASSOC);
		
		//Remove the file
		if (file_exists('storage/'.$document['document'])) {
			$old = getcwd();
			chdir('storage/');
			unlink($document['document']);
			chdir($old);
		}
		
		//Remove the entry
		$sql = "DELETE FROM documents WHERE document_id='".$_REQUEST['did']."'";
		$db->query($sql);
		
		//Set messaging
		$_SESSION['hom']['message'] = array("success", "You have removed a document");
		
		//Redirect to manage page
		header('location: manage-documents.php');
	}
}

/*------------------------------------------------
    /END DELETE PHASE
------------------------------------------------*/

?>