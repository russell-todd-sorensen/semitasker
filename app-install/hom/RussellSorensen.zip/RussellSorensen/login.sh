#!/bin/bash

sftp u69387551-russ@home420142412.1and1-data.host

