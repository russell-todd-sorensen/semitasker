-- query-writer-create.sql

-- Create Query Writer Data Model
--
-- @author Tom Jackson (tom@junom.com)
-- @creation-date 26 January 2002
-- @cvs-id $Id: query-writer-create.sql,v 1.6 2002/03/15 19:51:03 nsadmin Exp $
--

\i qw-objects-create.sql
\i qw-attrs-create.sql
\i qw-attrs-comments-create.sql
\i qw-groups-create.sql
\i qw-obj-procs-create.sql
\i qw-fns-create.sql

